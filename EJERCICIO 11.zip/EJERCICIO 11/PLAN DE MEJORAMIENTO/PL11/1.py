ciudades = ['Tokyo','New York','Toronto','Hong Kong']
print('Ciudades loop:')
for x in ciudades:
    print('Ciudad: ' + x)
 
print('\n')      