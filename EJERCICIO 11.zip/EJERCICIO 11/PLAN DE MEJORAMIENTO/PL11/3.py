def funcion(dictionary):
    for d in dictionary.values():
        print(d)
e={"cama":"lit", "silla":"chaise", "lampara":"lampe"}
funcion(e)   