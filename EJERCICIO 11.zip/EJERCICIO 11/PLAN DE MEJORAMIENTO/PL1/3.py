j=-1
k=0
l=1
rta=(l>j) and (l>k) or not (k>j) and (k<l)
print(rta)