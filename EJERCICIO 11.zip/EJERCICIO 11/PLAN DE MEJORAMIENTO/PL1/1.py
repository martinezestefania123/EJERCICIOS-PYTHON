x=4
y=3
z=2
rta= (z>x) and (x>y) or not (z>x) and (y<x)
print(rta)