d=-9
e=-12
f=6
rta=(d<e) and (d<f) or not (e>d) and (e<f)
print(rta)