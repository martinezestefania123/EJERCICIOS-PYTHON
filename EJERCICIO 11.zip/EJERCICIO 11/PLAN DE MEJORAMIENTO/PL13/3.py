k=False
l=False
m=True
rta=k and m or m and l
print(rta)