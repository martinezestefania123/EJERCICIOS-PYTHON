x=False
d=True
c=False
rta=d and c or x and c
print(rta)