t=True
u=False
v=True
rta=t and v or t and u
print(rta)
