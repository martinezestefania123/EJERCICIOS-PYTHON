def funcion(tam):
    lista=[k/8 for k in range (tam)]
    print(lista)
funcion(40)