def funcion(tam):
    lista=[n*3 for n in range (tam)]
    print(lista)
funcion(60)