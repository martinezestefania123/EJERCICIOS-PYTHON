def funcion(tam):
    lista=[g+2 for g in range (tam)]
    print(lista)
funcion(15)