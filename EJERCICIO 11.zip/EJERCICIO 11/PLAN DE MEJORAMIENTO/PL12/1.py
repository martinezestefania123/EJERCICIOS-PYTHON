print("el cielo esta\n en ladrillado.")
print()
print("quien lo desenladrillara\n")