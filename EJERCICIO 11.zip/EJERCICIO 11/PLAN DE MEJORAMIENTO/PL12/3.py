print("la mariposa estaba,",end="*""en la cocina haciendo.\n")
print()
print("gaciendo chocolate\n")