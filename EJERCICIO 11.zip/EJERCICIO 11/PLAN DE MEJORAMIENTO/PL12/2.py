print("los pollitos dicen\n pio pio.", end="-")
print()
print("cuando tienen hambre\n cuando tienen frio\n")