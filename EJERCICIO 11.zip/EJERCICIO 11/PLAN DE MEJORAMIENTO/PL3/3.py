r=-1
s=7
t=-3
rta=s*t+r%r+t+r
print(rta)