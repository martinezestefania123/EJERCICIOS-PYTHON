o=3
p=5
q=4
rta=p//o+q*q-o+p
print(rta)