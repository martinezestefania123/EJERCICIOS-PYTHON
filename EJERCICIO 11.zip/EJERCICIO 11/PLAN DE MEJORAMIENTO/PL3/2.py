g=-8
h=-3
i=-6
rta=h/i-g**g+h-g
print(rta)