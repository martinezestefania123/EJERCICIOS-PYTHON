def funcion(t,u):
    if t>u:
        print('positivo')
    elif t<u:
        print('negativo')
    else:
        print('iguales')
t=-9
u=8
funcion(t,u)