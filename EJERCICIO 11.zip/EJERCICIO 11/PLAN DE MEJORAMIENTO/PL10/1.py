def funcion(a,b):
    if a>b:
        print('decendente')
    elif a<b:
        print('ascendente')
    else:
        print('iguales')
a=3/6
b=3/7
funcion(a,b)