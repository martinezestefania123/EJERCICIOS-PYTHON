def funcion(d,f):
    if d>f:
        print('mayor')
    elif d<f:
        print('menor')
    else:
        print('iguales')
d=345
f=200
funcion(d,f)