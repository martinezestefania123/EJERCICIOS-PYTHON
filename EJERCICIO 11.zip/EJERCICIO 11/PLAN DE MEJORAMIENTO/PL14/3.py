dia=input("Dia de la semana: ")
if (dia=="lunes"):
    print("Oh, no!")
elif (dia=="viernes"):
    print("¡Ya casi!")
elif (dia=="sábado" or "domingo"):
    print("Ahora sí se puede descansar")
else:
    print("A esperar el fin de semana")