a=int(input("Un número: "))
b=int(input("Otro número: "))
if a<b:
    print("El primero es menor")
elif b<a:
    print("El segundo es menor")
else:
    print("Son iguales")