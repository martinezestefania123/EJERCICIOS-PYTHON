edades = [12,15,23,30,50]
cantidad =0
for num in edades:
	if (num%3 == 0):
		cantidad+=1
print(cantidad)