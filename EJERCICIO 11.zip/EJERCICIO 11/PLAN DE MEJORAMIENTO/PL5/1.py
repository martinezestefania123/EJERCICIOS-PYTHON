edad=28
if edad >= 18:
	print('Puedes acceder, eres mayor de edad.')
else:
	print('No puedes acceder, eres menor de edad.')