def funcion(m,n):
    for p in range(m):
        for q in range(n):
            print(p,'-',q)
funcion(6,6)