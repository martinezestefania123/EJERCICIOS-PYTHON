def funcion(u,v):
    for s in range(u):
        for t in range(v):
            print(s,'-',t)
funcion(9,9)