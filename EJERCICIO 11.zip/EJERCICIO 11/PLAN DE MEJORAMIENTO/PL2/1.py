def funcion(c,d):
    for a in range(c):
        for b in range(d):
            print(a,'-',b)
funcion(3,3)