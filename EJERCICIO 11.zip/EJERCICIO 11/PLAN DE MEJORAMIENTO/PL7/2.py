x = 0

while x < 10:
	x += 1
	if x == 5 or x == 7:
		continue
	print(x)