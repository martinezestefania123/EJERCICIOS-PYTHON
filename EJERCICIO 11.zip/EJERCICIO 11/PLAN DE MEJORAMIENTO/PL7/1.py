x = 1

while x <= 10:
	print(x)
	if x == 5:
		break
	x += 1