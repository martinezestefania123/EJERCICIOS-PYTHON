def funcion(tupla,start,end):
    print(tupla[start:end])

vec=(5,8,6,2,4,9,7)
funcion(vec,3,-1)