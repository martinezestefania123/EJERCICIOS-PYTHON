def funcion(tupla,start,end):
    print(tupla[start:end])

vec=(13,5,17,4,10,3,19)
funcion(vec,2,-2)