def funcion(tupla,start,end):
    print(tupla[start:end])

vec=(70,50,60,40,10,30,20)
funcion(vec,1,-1)